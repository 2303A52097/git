from flask import Flask, jsonify, request
app = Flask('search')
HOTELS = [
    {'id':1,'name':'Hotel Sunrise','city':'Hyderabad','price':2500},
    {'id':2,'name':'Lakeview Resort','city':'Bangalore','price':4200},
    {'id':3,'name':'City Inn','city':'Delhi','price':1800},
]

@app.route('/search')
def search():
    city = request.args.get('city','')
    results = [h for h in HOTELS if city.lower() in h['city'].lower()] if city else HOTELS
    return jsonify(results)

if __name__=='__main__':
    app.run(port=6001)
