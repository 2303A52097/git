# Hotel Booking Prototypes (Monolith & Microservices)

This package contains two Python/Flask prototypes:

1. Monolith app (single Flask app):
   - Folder: monolith
   - Run: python app.py
   - Open: http://127.0.0.1:5000

2. Microservices (3 services + gateway):
   - Folder: microservices
   - Start in separate terminals:
     python search_service.py   (port 6001)
     python booking_service.py  (port 6002)
     python payment_service.py  (port 6003)
     python gateway.py          (port 5000)
   - Open: http://127.0.0.1:5000 (gateway)

Requirements:
- Python 3.8+
- pip install flask requests

Notes:
- These prototypes are intentionally minimal for learning/demo purposes.
- The monolith uses an SQLite file created on first run (monolith/hotels.db).
- The microservices use in-memory data structures.
