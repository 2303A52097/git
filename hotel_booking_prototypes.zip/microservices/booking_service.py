from flask import Flask, request, jsonify
app = Flask('booking')
BOOKINGS = []

@app.route('/book', methods=['POST'])
def book():
    data = request.json
    booking_id = len(BOOKINGS)+1
    BOOKINGS.append({**data,'id':booking_id,'status':'CONFIRMED'})
    return jsonify({'booking_id':booking_id,'status':'CONFIRMED'})

if __name__=='__main__':
    app.run(port=6002)
