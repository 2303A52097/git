from flask import Flask, request, jsonify, render_template
import requests
app = Flask('gateway', template_folder='frontend')

SEARCH_URL = 'http://127.0.0.1:6001/search'
BOOK_URL = 'http://127.0.0.1:6002/book'
PAY_URL = 'http://127.0.0.1:6003/pay'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/search')
def api_search():
    city = request.args.get('city','')
    r = requests.get(SEARCH_URL, params={'city':city})
    return jsonify(r.json())

@app.route('/api/book', methods=['POST'])
def api_book():
    data = request.json
    # call booking service
    r = requests.post(BOOK_URL, json=data)
    book_resp = r.json()
    # call payment service (simulate)
    p = requests.post(PAY_URL, json={'amount':data.get('amount',0)})
    pay_resp = p.json()
    return jsonify({'booking':book_resp,'payment':pay_resp})

if __name__=='__main__':
    app.run(port=5000)
