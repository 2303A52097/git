from flask import Flask, render_template, request, redirect, url_for
import sqlite3
from pathlib import Path

DB = Path(__file__).parent / 'hotels.db'

def init_db():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS hotels (id INTEGER PRIMARY KEY, name TEXT, city TEXT, price REAL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS bookings (id INTEGER PRIMARY KEY, hotel_id INTEGER, guest_name TEXT, check_in TEXT, check_out TEXT, status TEXT)''')
    # seed
    c.execute('SELECT COUNT(*) FROM hotels')
    if c.fetchone()[0] == 0:
        hotels = [
            ('Hotel Sunrise','Hyderabad', 2500),
            ('Lakeview Resort','Bangalore', 4200),
            ('City Inn','Delhi', 1800),
        ]
        c.executemany('INSERT INTO hotels (name, city, price) VALUES (?,?,?)', hotels)
    conn.commit(); conn.close()

app = Flask(__name__)
init_db()

def query_hotels(city=None):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    if city:
        c.execute('SELECT id,name,city,price FROM hotels WHERE city LIKE ?', (f'%{city}%',))
    else:
        c.execute('SELECT id,name,city,price FROM hotels')
    rows = c.fetchall(); conn.close()
    return rows

@app.route('/', methods=['GET','POST'])
def index():
    city = request.form.get('city') if request.method=='POST' else request.args.get('city')
    hotels = query_hotels(city)
    return render_template('index.html', hotels=hotels, city=city or '')

@app.route('/book', methods=['POST'])
def book():
    hotel_id = request.form['hotel_id']
    guest = request.form['guest']
    check_in = request.form['check_in']
    check_out = request.form['check_out']
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('INSERT INTO bookings (hotel_id,guest_name,check_in,check_out,status) VALUES (?,?,?,?,?)', (hotel_id,guest,check_in,check_out,'CONFIRMED'))
    conn.commit(); booking_id = c.lastrowid; conn.close()
    return render_template('confirm.html', booking_id=booking_id, guest=guest)

if __name__ == '__main__':
    app.run(debug=True)
