from flask import Flask, request, jsonify
app = Flask('payment')

@app.route('/pay', methods=['POST'])
def pay():
    # naive: always success
    return jsonify({'status':'PAID','transaction_id': 'TX'+str(12345)})

if __name__=='__main__':
    app.run(port=6003)
